# Method one: This method calculates the 
#gross sales by multiplying the number 
#of items sold by the fixed price per unit ($10).
def calculate_gross_sales(items_sold):
    total_sales = 10 * items_sold 
    return total_sales


# Method two: This methodcalculates the commission
 #percentage based on the number of items sold using
#the provided sales commission schedule.
def calculate_commission_percentage(items_sold):
    if items_sold <= 50:
        commission_percentage = 6
    elif items_sold <= 100:
        commission_percentage = 7
    elif items_sold <= 150:
        commission_percentage = 8
    else:
        commission_percentage = 9
    return commission_percentage


# Method three: This method calculates the salesperson's earnings 
#by multiplying the gross sales by the commission percentage and 
#dividing by 100
def calculate_earnings(gross_sales, commission_percentage):
    earnings = (gross_sales * commission_percentage) / 100  
    return earnings


# Input the number of items sold
items_sold = int(input("Enter the number of items sold: "))

# Call the methods and display the results
gross_sales = calculate_gross_sales(items_sold)
print("Gross Sales:", gross_sales)

commission_percentage = calculate_commission_percentage(items_sold)
print("Commission Percentage:", commission_percentage, "%")

earnings_value = calculate_earnings(gross_sales, commission_percentage)
print("Earnings:", earnings_value)

#SHORT SUMMARY:When the program is executed, it prompts the user to input 
#the number of items sold,calculates the gross sales, commission percentage,
# and the salesperson's earnings, and then displays the results.